'use client'

import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import type { Product } from '@/lib/store'
import { doc, getDoc, setDoc } from 'firebase/firestore'
import { AuthProvider, useAuth } from '@/components/auth-provider'
import { db } from '@/lib/firebase'

type CartItem = Product & { size: string; quantity: number }
type CartContextValue = { items: CartItem[]; addItem: (product: Product, size: string, quantity: number) => void; removeItem: (id: string, size: string) => void; updateQuantity: (id: string, size: string, quantity: number) => void; count: number; total: number }
const CartContext = createContext<CartContextValue | null>(null)
const CART_KEY = 'stampa-sur-cart'

export function Providers({ children }: { children: ReactNode }) {
  return <AuthProvider><CartProvider>{children}</CartProvider></AuthProvider>
}

function CartProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth()
  const [items, setItems] = useState<CartItem[]>([])
  const [hydrated, setHydrated] = useState(false)

  useEffect(() => {
    try { setItems(JSON.parse(window.localStorage.getItem(CART_KEY) ?? '[]')) } catch { setItems([]) }
    setHydrated(true)
  }, [])

  useEffect(() => {
    if (hydrated) window.localStorage.setItem(CART_KEY, JSON.stringify(items))
  }, [hydrated, items])

  useEffect(() => {
    if (!user || !hydrated) return
    const sync = async () => {
      const ref = doc(db, 'usuarios', user.uid)
      const snapshot = await getDoc(ref)
      const remote = Array.isArray(snapshot.data()?.carrito) ? snapshot.data()?.carrito as CartItem[] : []
      const merged = [...remote]
      for (const item of items) {
        const index = merged.findIndex((entry) => entry.id === item.id && entry.size === item.size)
        if (index >= 0) merged[index] = { ...merged[index], quantity: Math.min(merged[index].quantity + item.quantity, item.stock) }
        else merged.push(item)
      }
      setItems(merged)
      await setDoc(ref, { carrito: merged }, { merge: true })
    }
    sync().catch((error) => console.log('[v0] Error sincronizando carrito:', error))
  }, [user, hydrated])

  const addItem = (product: Product, size: string, quantity: number) => setItems((current) => { const found = current.find((item) => item.id === product.id && item.size === size); return found ? current.map((item) => item === found ? { ...item, quantity: Math.min(item.quantity + quantity, product.stock) } : item) : [...current, { ...product, size, quantity }] })
  const removeItem = (id: string, size: string) => setItems((current) => current.filter((item) => !(item.id === id && item.size === size)))
  const updateQuantity = (id: string, size: string, quantity: number) => setItems((current) => current.map((item) => item.id === id && item.size === size ? { ...item, quantity: Math.max(1, Math.min(quantity, item.stock)) } : item))
  const value = useMemo(() => ({ items, addItem, removeItem, updateQuantity, count: items.reduce((sum, item) => sum + item.quantity, 0), total: items.reduce((sum, item) => sum + item.quantity * item.price, 0) }), [items])
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export const useCart = () => { const context = useContext(CartContext); if (!context) throw new Error('useCart debe usarse dentro de Providers'); return context }
