'use client'

import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight, Camera, Menu, Search, ShoppingBag, UserRound } from 'lucide-react'
import { ChangeEvent, useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { CursorGlow, ScrollReveal } from '@/components/motion-effects'
import { ShirtCustomizer as Configurator } from '@/components/shirt-customizer'

const logoUrl = 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ChatGPT%20Image%206%20oct%202026%2C%2004_55_52%20a.m.-zPklwroSvyEF9Yi7wtxBhbBPxOVnx3.png'

const products = [
  { name: 'Dragón Sur', detail: 'Remera premium · Negro', price: '$32.000', image: '/placeholder.jpg' },
  { name: 'Sello del Sur', detail: 'Remera oversize · Negro', price: '$30.000', image: '/placeholder.jpg' },
  { name: 'Estampa I', detail: 'Remera premium · Crudo', price: '$32.000', image: '/placeholder.jpg' },
]

const shirtColors = [
  { name: 'Negro', value: '#121212' },
  { name: 'Blanco', value: '#f2f0eb' },
  { name: 'Gris', value: '#777777' },
  { name: 'Azul noche', value: '#18253b' },
  { name: 'Borgoña', value: '#5d1f2b' },
]

function ShirtPreview({ color, design }: { color: string; design: string }) {
  return <div className="relative mx-auto aspect-[0.85] w-full max-w-[360px] overflow-hidden rounded-sm bg-[#0d0d0d] p-5 shadow-[0_20px_70px_rgba(0,0,0,0.45)]"><svg viewBox="0 0 360 430" className="h-full w-full" role="img" aria-label="Vista previa de la remera"><path fill={color} d="M92 54 142 25h76l50 29 78 73-45 58-43-37v244H102V148l-43 37-45-58 78-73Z" /><path fill="none" stroke="rgba(255,255,255,.16)" strokeWidth="3" d="M142 25c8 31 20 45 38 45s30-14 38-45M102 148l22 18m134-18-22 18" /></svg>{design && <img src={design} alt="Tu diseño sobre la remera" className="absolute left-1/2 top-[45%] max-h-28 w-28 -translate-x-1/2 -translate-y-1/2 object-contain" />}</div>
}

function ShirtCustomizer() {
  const [size, setSize] = useState('M')
  const [color, setColor] = useState(shirtColors[0])
  const [design, setDesign] = useState('')

  useEffect(() => () => { if (design) URL.revokeObjectURL(design) }, [design])

  function handleDesign(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    if (!file) return
    if (design) URL.revokeObjectURL(design)
    setDesign(URL.createObjectURL(file))
  }

  const whatsappMessage = encodeURIComponent(`Hola, quiero personalizar una remera. Talle: ${size}, Color: ${color.name}. Les adjunto mi diseño por WhatsApp.`)

  return <section className="border-y border-white/10 bg-[#11100e] px-5 py-24 lg:px-10" id="personalizar"><ScrollReveal className="mx-auto max-w-7xl"><div className="mb-12 max-w-2xl"><p className="mb-4 text-[10px] uppercase tracking-[0.4em] text-[#c8b995]">Diseñá la tuya</p><h2 className="font-serif text-5xl leading-none sm:text-7xl">Personalizá tu remera</h2><p className="mt-6 text-sm leading-7 text-white/55">Elegí el talle, el color y subí tu diseño. Nosotros lo estampamos.</p></div><div className="grid gap-12 lg:grid-cols-[0.8fr_1fr] lg:items-center"><div className="order-2 flex flex-col gap-7 lg:order-1"><fieldset><legend className="mb-3 text-[10px] uppercase tracking-[0.25em] text-white/55">Talle</legend><div className="flex flex-wrap gap-2">{['S', 'M', 'L', 'XL', 'XXL'].map((item) => <button type="button" key={item} onClick={() => setSize(item)} aria-pressed={size === item} className={`size-11 border text-xs transition ${size === item ? 'border-[#c9a961] bg-[#c9a961] text-black' : 'border-white/15 text-white/65 hover:border-[#c9a961]'}`}>{item}</button>)}</div></fieldset><fieldset><legend className="mb-3 text-[10px] uppercase tracking-[0.25em] text-white/55">Color de remera · {color.name}</legend><div className="flex gap-3">{shirtColors.map((item) => <button type="button" key={item.name} onClick={() => setColor(item)} aria-label={item.name} aria-pressed={color.name === item.name} className={`size-9 rounded-full border-2 transition ${color.name === item.name ? 'border-[#c9a961] ring-2 ring-[#c9a961]/30 ring-offset-2 ring-offset-[#11100e]' : 'border-white/25'}`} style={{ backgroundColor: item.value }} />)}</div></fieldset><div className="flex flex-col gap-3"><label htmlFor="design-upload" className="cursor-pointer border border-dashed border-white/20 px-4 py-4 text-xs uppercase tracking-[0.15em] text-[#c9a961] transition hover:border-[#c9a961]">{design ? 'Cambiar diseño PNG' : 'Subir diseño PNG'}</label><input id="design-upload" type="file" accept="image/png" onChange={handleDesign} className="sr-only" /><p className="text-xs leading-6 text-white/55">Subí tu diseño en PNG con fondo transparente. Si la imagen tiene fondo, se va a estampar tal cual.</p><p className="border-l-2 border-[#c9a961] bg-[#c9a961]/10 px-4 py-3 text-xs leading-6 text-[#eadcb8]">Importante: Subí tu diseño en formato PNG con fondo transparente. Si tu imagen tiene fondo, por ejemplo blanco, se va a estampar tal cual, incluyendo el fondo.</p></div><a href={`https://wa.me/5490000000000?text=${whatsappMessage}`} target="_blank" rel="noreferrer" className="inline-flex w-fit items-center justify-center bg-[#c9a961] px-6 py-4 text-[10px] font-semibold uppercase tracking-[0.25em] text-black transition hover:bg-[#eadcb8]">Consultar por WhatsApp</a></div><div className="order-1 lg:order-2"><ShirtPreview color={color.value} design={design} /><p className="mt-4 text-center text-[10px] uppercase tracking-[0.25em] text-white/35">Vista previa · {size} · {color.name}</p></div></div></ScrollReveal></section>
}

export default function Page() {
  const [menuOpen, setMenuOpen] = useState(false)
  return (
    <main className="min-h-screen overflow-hidden bg-[#080808] text-[#f2f0eb]"><CursorGlow />
      <header className="relative z-20 border-b border-white/10 bg-[#080808]/90 backdrop-blur-xl">
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 lg:px-10">
          <Link href="/" aria-label="Stampa Sur inicio" className="flex items-center gap-3">
            <Image src={logoUrl} alt="Logo de Stampa Sur" width={62} height={62} className="size-12 object-contain" unoptimized />
            <span className="font-serif text-xl tracking-[0.18em]">STAMPA <span className="text-[#a9a496]">SUR</span></span>
          </Link>
          <nav className="hidden items-center gap-9 text-[11px] uppercase tracking-[0.25em] text-white/65 md:flex">
            <Link className="text-white transition-colors hover:text-[#c8b995]" href="/">Inicio</Link>
            <Link className="transition-colors hover:text-[#c8b995]" href="/tienda">Tienda</Link>
            <a className="transition-colors hover:text-[#c8b995]" href="#colecciones">Secciones</a>
            <a className="transition-colors hover:text-[#c8b995]" href="#contacto">Contacto</a>
          </nav>
          <div className="flex items-center gap-4">
            <button aria-label="Buscar" className="hidden text-white/70 transition hover:text-white sm:block"><Search className="size-4" /></button>
            <Link href="/carrito" aria-label="Carrito" className="relative text-white/70 transition hover:text-white"><ShoppingBag className="size-5" /><span className="absolute -right-2 -top-2 flex size-4 items-center justify-center rounded-full bg-[#c8b995] text-[9px] font-semibold text-black">0</span></Link>
            <Link href="/login" aria-label="Iniciar sesión" className="hidden text-white/70 transition hover:text-white sm:block"><UserRound className="size-5" /></Link>
            <button aria-label="Abrir menú" onClick={() => setMenuOpen(!menuOpen)} className="md:hidden"><Menu className="size-5" /></button>
          </div>
        </div>
        {menuOpen && <nav className="flex flex-col gap-5 border-t border-white/10 px-5 py-6 text-xs uppercase tracking-[0.25em] md:hidden"><Link href="/">Inicio</Link><Link href="/tienda">Tienda</Link><a href="#colecciones">Secciones</a><a href="#contacto">Contacto</a></nav>}
      </header>

      <section className="relative isolate flex min-h-[calc(100vh-5rem)] items-center border-b border-white/10 px-5 py-20 lg:px-10">
        <div className="absolute inset-0 -z-10 opacity-[0.07]" style={{ backgroundImage: 'radial-gradient(circle at 50% 45%, #c9a961 0, transparent 34%)' }} /><Image src={logoUrl} alt="" aria-hidden width={900} height={900} className="dragon-breathe pointer-events-none absolute left-1/2 top-1/2 -z-10 w-[min(92vw,900px)] -translate-x-1/2 -translate-y-1/2 object-contain opacity-25" unoptimized />
        <div className="mx-auto grid w-full max-w-7xl items-center gap-12 lg:grid-cols-[1fr_0.8fr]">
          <ScrollReveal className="max-w-2xl">
            <p className="mb-8 text-[10px] uppercase tracking-[0.45em] text-[#c8b995]">Hecho en el sur · Desde 2024</p>
            <h1 className="font-serif text-6xl leading-[0.9] tracking-[-0.04em] sm:text-8xl lg:text-[9.5rem]">Vestí tu<br /><span className="text-[#c8b995]">identidad.</span></h1>
            <p className="mt-9 max-w-md text-sm leading-7 text-white/55">Remeras estampadas con identidad propia. Diseños que nacen de la calle, la música y el pulso de nuestra tierra.</p>
            <motion.div whileHover={{ y: -2, boxShadow: '0 0 24px rgba(201,169,97,0.2)' }} whileTap={{ scale: 0.97 }} className="mt-10 inline-flex"><Link href="/tienda" className="inline-flex items-center gap-4 border border-[#c8b995] px-6 py-4 text-[10px] uppercase tracking-[0.3em] text-[#c8b995] transition hover:bg-[#c8b995] hover:text-black">Explorar colección <ArrowRight className="size-4" /></Link></motion.div>
          </ScrollReveal>
          <div className="relative mx-auto flex max-w-[430px] items-center justify-center" aria-hidden><div className="size-[70%] rounded-full border border-dashed border-[#c8b995]/20 opacity-40" /></div>
        </div>
        <div className="absolute bottom-8 left-5 flex items-center gap-4 text-[9px] uppercase tracking-[0.3em] text-white/35 lg:left-10"><span className="h-px w-10 bg-white/30" /> Scroll para descubrir</div>
      </section>

      <Configurator />

      <section className="mx-auto max-w-7xl px-5 py-24 lg:px-10" id="colecciones">
        <div className="mb-12 flex items-end justify-between gap-6"><div><p className="mb-3 text-[10px] uppercase tracking-[0.4em] text-[#c8b995]">Selección editorial</p><h2 className="font-serif text-4xl sm:text-5xl">Piezas destacadas</h2></div><Link href="/tienda" className="hidden items-center gap-2 text-[10px] uppercase tracking-[0.25em] text-white/55 hover:text-[#c8b995] sm:flex">Ver todo <ArrowRight className="size-4" /></Link></div>
        <div className="grid gap-5 sm:grid-cols-3">{products.map((product, index) => <ScrollReveal key={product.name} delay={index * 0.08}><motion.article whileHover={{ y: -5 }} className="group"><div className="relative aspect-[0.84] overflow-hidden bg-[#151515]"><div className="absolute inset-0 flex items-center justify-center"><div className="size-40 rounded-full border border-[#c8b995]/15" /><span className="absolute font-serif text-5xl text-white/10">{String(index + 1).padStart(2, '0')}</span></div><div className="absolute inset-x-0 bottom-0 flex translate-y-full justify-center p-5 transition-transform group-hover:translate-y-0"><Link href={`/producto/${index + 1}`} className="bg-[#f2f0eb] px-5 py-3 text-[10px] uppercase tracking-[0.2em] text-black">Ver producto</Link></div></div><div className="flex items-start justify-between pt-4"><div><h3 className="font-serif text-xl">{product.name}</h3><p className="mt-1 text-xs text-white/45">{product.detail}</p></div><span className="text-sm text-[#c8b995]">{product.price}</span></div></motion.article></ScrollReveal>)}</div>
      </section>

      <section className="border-y border-white/10 bg-[#11100e] px-5 py-24 lg:px-10"><ScrollReveal className="mx-auto max-w-7xl"><a href="https://www.instagram.com/stampa.sur/" target="_blank" rel="noopener noreferrer" className="mb-10 inline-flex w-fit items-center gap-3 border border-[#c8b995] px-5 py-3 text-[10px] uppercase tracking-[0.22em] text-[#c8b995] transition hover:bg-[#c8b995] hover:text-black hover:shadow-[0_0_24px_rgba(201,169,97,0.2)]"><span aria-hidden className="instagram-mark"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="size-4"><rect x="3.5" y="3.5" width="17" height="17" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" /></svg></span> Seguinos en Instagram</a><div className="grid gap-12 lg:grid-cols-[0.8fr_1fr]"><div><p className="mb-4 text-[10px] uppercase tracking-[0.4em] text-[#c8b995]">Nuestra esencia</p><h2 className="max-w-lg font-serif text-5xl leading-none sm:text-7xl">No seguimos<br /><i>tendencias.</i></h2></div><p className="max-w-md self-end text-sm leading-8 text-white/55">Creamos prendas para quienes eligen caminar su propio camino. Una colección pensada para durar, diseñada en el sur y estampada con carácter.</p></div></ScrollReveal></section>

      <footer id="contacto" className="mx-auto flex max-w-7xl flex-col gap-8 px-5 py-12 sm:flex-row sm:items-end sm:justify-between lg:px-10"><div className="flex items-center gap-4"><Image src={logoUrl} alt="Logo de Stampa Sur" width={80} height={80} className="size-12 object-contain" unoptimized /><div><p className="font-serif text-2xl tracking-[0.16em]">STAMPA SUR</p><p className="mt-2 text-xs text-white/40">Remeras con identidad propia.</p></div></div><div className="flex items-center gap-6 text-white/50"><a href="https://www.instagram.com/stampa.sur/" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="hover:text-[#c8b995]"><span aria-hidden className="instagram-mark"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="size-4"><rect x="3.5" y="3.5" width="17" height="17" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" /></svg></span></a><span className="text-[10px] uppercase tracking-[0.25em]">Buenos Aires, Argentina</span></div></footer>
    </main>
  )
}
