export const CONFIG_PERSONALIZACION = {
  whatsappNumber: '5491123456789',
  tallesDisponibles: ['S', 'M', 'L', 'XL', 'XXL'],
  coloresDisponibles: [
    { nombre: 'Negro', hex: '#000000' },
    { nombre: 'Blanco', hex: '#FFFFFF' },
    { nombre: 'Gris', hex: '#808080' },
    { nombre: 'Azul oscuro', hex: '#1a237e' },
    { nombre: 'Rojo oscuro', hex: '#b71c1c' },
  ],
  precioBase: 15000,
  mensajeWhatsapp: 'Hola Stamapa Sur! Quiero personalizar una remera.',
} as const
