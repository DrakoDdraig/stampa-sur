'use client'

import Image from 'next/image'
import Link from 'next/link'
import { Menu, Search, ShoppingBag, UserRound, X } from 'lucide-react'
import { useState } from 'react'
import { useCart } from '@/app/providers'
import { AnimatedHeader, CartPop, CursorGlow } from '@/components/motion-effects'
import { useAuth } from '@/components/auth-provider'

const logoUrl = 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ChatGPT%20Image%206%20oct%202026%2C%2004_55_52%20a.m.-zPklwroSvyEF9Yi7wtxBhbBPxOVnx3.png'

export function ShopHeader() {
  const [open, setOpen] = useState(false)
  const { count } = useCart()
  const { user } = useAuth()
  const accountLink = user ? <Link href="/mi-cuenta">Mi cuenta</Link> : <Link href="/login">Iniciar sesión</Link>
  return <><CursorGlow /><AnimatedHeader><Link href="/" className="flex items-center gap-3"><Image src={logoUrl} alt="Logo Stampa Sur" width={120} height={120} unoptimized className="size-14 object-contain" /><span className="font-serif text-lg tracking-[0.16em]">STAMPA <span className="text-[#aaa398]">SUR</span></span></Link><nav className="hidden items-center gap-8 text-[10px] uppercase tracking-[0.28em] text-white/60 md:flex"><Link href="/">Inicio</Link><Link className="text-[#c8b995]" href="/tienda">Tienda</Link>{accountLink}</nav><div className="flex items-center gap-4"><button aria-label="Buscar" className="text-white/70"><Search className="size-4" /></button><Link href="/carrito" aria-label={`Carrito, ${count} productos`} className="relative"><ShoppingBag className="size-5" /><CartPop count={count} /></Link>{user ? <Link href="/mi-cuenta" className="hidden items-center gap-2 text-xs text-white/70 sm:flex"><UserRound className="size-5" /><span className="max-w-24 truncate">{user.displayName ?? user.email?.split('@')[0]}</span></Link> : <Link href="/login" className="hidden text-[10px] uppercase tracking-[0.15em] text-white/60 sm:block">Iniciar sesión</Link>}<button aria-label="Menú" className="md:hidden" onClick={() => setOpen(!open)}>{open ? <X className="size-5" /> : <Menu className="size-5" />}</button></div></AnimatedHeader>{open && <nav className="flex flex-col gap-5 border-t border-white/10 px-5 py-6 text-[10px] uppercase tracking-[0.28em] md:hidden"><Link href="/">Inicio</Link><Link href="/tienda">Tienda</Link>{accountLink}</nav>}</>
}
