'use client'

import Image from 'next/image'
import { useEffect, useMemo, useState, type ChangeEvent, type ReactNode } from 'react'
import { Bell, Box, ChevronDown, CircleAlert, LayoutDashboard, LogOut, Menu, PackagePlus, Settings, ShoppingCart, Users, X } from 'lucide-react'
import { AdminCustomer, AdminOrder, AdminProduct, formatARS, getAdminData } from '@/lib/admin-data'

const logoUrl = 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ChatGPT%20Image%206%20oct%202026%2C%2004_55_52%20a.m.-zPklwroSvyEF9Yi7wtxBhbBPxOVnx3.png'

const navItems = [
  { label: 'Resumen', icon: LayoutDashboard },
  { label: 'Productos', icon: Box },
  { label: 'Pedidos', icon: ShoppingCart },
  { label: 'Clientes', icon: Users },
]

const statusClasses: Record<string, string> = {
  Pendiente: 'bg-[#c8b995]/15 text-[#d9c99e]',
  'En preparación': 'bg-blue-400/10 text-blue-300',
  Enviado: 'bg-violet-400/10 text-violet-300',
  Entregado: 'bg-emerald-400/10 text-emerald-300',
  Activo: 'bg-emerald-400/10 text-emerald-300',
  Agotado: 'bg-red-400/10 text-red-300',
}

export default function AdminPage() {
  const [active, setActive] = useState('Resumen')
  const [data, setData] = useState<{ products: AdminProduct[]; orders: AdminOrder[]; customers: AdminCustomer[] } | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [mobileNav, setMobileNav] = useState(false)
  const [showProductForm, setShowProductForm] = useState(false)
  const [editingProduct, setEditingProduct] = useState<AdminProduct | undefined>()

  useEffect(() => {
    getAdminData().then(setData).catch(() => setError('No pudimos cargar los datos demo. Intentá nuevamente.')).finally(() => setLoading(false))
  }, [])

  const revenue = useMemo(() => data?.orders.reduce((sum, order) => sum + order.total, 0) ?? 0, [data])
  const currentDescription = active === 'Resumen' ? 'Una mirada general de tu tienda.' : `Gestioná ${active.toLowerCase()} desde un solo lugar.`

  return (
    <main className="min-h-screen bg-[#0b0b0b] text-[#f2f0eb]">
      <aside className={`${mobileNav ? 'translate-x-0' : '-translate-x-full'} fixed inset-y-0 left-0 z-30 flex w-64 flex-col border-r border-white/10 bg-[#101010] transition-transform lg:translate-x-0`}>
        <div className="flex h-20 items-center justify-between border-b border-white/10 px-6"><div className="flex items-center gap-3"><Image src={logoUrl} alt="Logo de Stampa Sur" width={42} height={42} className="size-9 object-contain" unoptimized /><div><p className="font-serif text-lg tracking-[0.18em]">STAMPA <span className="text-[#c8b995]">SUR</span></p><p className="mt-1 text-[9px] uppercase tracking-[0.3em] text-white/35">Panel de administración</p></div></div><button className="lg:hidden" onClick={() => setMobileNav(false)} aria-label="Cerrar menú"><X className="size-5" /></button></div>
        <nav className="flex flex-1 flex-col gap-1 p-4">{navItems.map(({ label, icon: Icon }) => <button key={label} onClick={() => { setActive(label); setMobileNav(false) }} className={`flex items-center gap-3 px-4 py-3 text-left text-sm transition ${active === label ? 'border-l-2 border-[#c8b995] bg-[#c8b995]/10 text-[#e3d6b5]' : 'text-white/50 hover:bg-white/5 hover:text-white'}`}><Icon className="size-4" />{label}</button>)}<div className="mt-5 border-t border-white/10 pt-5"><button className="flex w-full items-center gap-3 px-4 py-3 text-sm text-white/50 hover:text-white"><Settings className="size-4" />Configuración</button><button className="flex w-full items-center gap-3 px-4 py-3 text-sm text-white/50 hover:text-white"><LogOut className="size-4" />Cerrar sesión</button></div></nav>
        <div className="border-t border-white/10 p-5"><div className="flex items-center gap-3"><div className="flex size-9 items-center justify-center rounded-full bg-[#c8b995] text-sm font-semibold text-black">AS</div><div><p className="text-sm">Admin Stampa</p><p className="text-xs text-white/35">Administrador</p></div></div></div>
      </aside>
      {mobileNav && <button className="fixed inset-0 z-20 bg-black/70 lg:hidden" onClick={() => setMobileNav(false)} aria-label="Cerrar navegación" />}
      <section className="lg:pl-64"><header className="flex h-20 items-center justify-between border-b border-white/10 px-5 lg:px-10"><div className="flex items-center gap-4"><button className="lg:hidden" onClick={() => setMobileNav(true)} aria-label="Abrir menú"><Menu className="size-5" /></button><div><h1 className="font-serif text-2xl">{active}</h1><p className="hidden text-xs text-white/40 sm:block">{currentDescription}</p></div></div><div className="flex items-center gap-4"><button className="text-white/55 hover:text-white" aria-label="Notificaciones"><Bell className="size-5" /></button><div className="hidden items-center gap-2 border-l border-white/10 pl-4 text-xs text-white/50 sm:flex"><span>Vista administrador</span><ChevronDown className="size-3" /></div></div></header>
        <div className="mx-auto max-w-[1400px] p-5 lg:p-10">{error ? <div className="flex items-center gap-3 border border-red-400/20 bg-red-400/10 p-4 text-sm text-red-200"><CircleAlert className="size-4" />{error}<button onClick={() => window.location.reload()} className="ml-auto underline">Reintentar</button></div> : loading ? <LoadingState /> : <>{active === 'Resumen' && <Overview revenue={revenue} products={data!.products} orders={data!.orders} setActive={setActive} />}{active === 'Productos' && <Products products={data!.products} onAdd={() => { setEditingProduct(undefined); setShowProductForm(true) }} onEdit={(product) => { setEditingProduct(product); setShowProductForm(true) }} />}{active === 'Pedidos' && <Orders orders={data!.orders} />}{active === 'Clientes' && <Customers customers={data!.customers} />}</>}{showProductForm && <ProductForm product={editingProduct} onClose={() => { setShowProductForm(false); setEditingProduct(undefined) }} />}</div>
      </section>
    </main>
  )
}

function LoadingState() { return <div className="flex min-h-[420px] items-center justify-center"><div className="flex flex-col items-center gap-4 text-white/45"><div className="size-8 animate-spin rounded-full border-2 border-[#c8b995] border-t-transparent" /><p className="text-sm">Cargando datos del panel...</p></div></div> }

function Overview({ revenue, products, orders, setActive }: { revenue: number; products: AdminProduct[]; orders: AdminOrder[]; setActive: (value: string) => void }) {
  const metrics = [{ label: 'Ventas del mes', value: formatARS(revenue), change: '+12,8%', icon: ShoppingCart }, { label: 'Pedidos', value: '48', change: '+8,4%', icon: PackagePlus }, { label: 'Clientes', value: '126', change: '+16,2%', icon: Users }, { label: 'Productos activos', value: String(products.filter((product) => product.status === 'Activo').length), change: 'Sin cambios', icon: Box }]
  return <div className="flex flex-col gap-8"><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{metrics.map(({ label, value, change, icon: Icon }) => <article key={label} className="border border-white/10 bg-[#111] p-5"><div className="flex items-center justify-between text-white/45"><p className="text-xs uppercase tracking-[0.15em]">{label}</p><Icon className="size-4 text-[#c8b995]" /></div><p className="mt-7 font-serif text-3xl">{value}</p><p className="mt-2 text-xs text-emerald-300">{change} <span className="text-white/30">vs. mes anterior</span></p></article>)}</div><div className="grid gap-6 xl:grid-cols-[1.25fr_0.75fr]"><section className="border border-white/10 bg-[#111] p-6"><div className="mb-7 flex items-center justify-between"><div><p className="text-[10px] uppercase tracking-[0.3em] text-[#c8b995]">Actividad reciente</p><h2 className="mt-2 font-serif text-2xl">Últimos pedidos</h2></div><button onClick={() => setActive('Pedidos')} className="text-[10px] uppercase tracking-[0.2em] text-white/45 hover:text-[#c8b995]">Ver todos</button></div><div className="overflow-x-auto"><table className="w-full min-w-[600px] text-left text-sm"><thead className="border-b border-white/10 text-[10px] uppercase tracking-[0.15em] text-white/35"><tr><th className="pb-3 font-normal">Pedido</th><th className="pb-3 font-normal">Cliente</th><th className="pb-3 font-normal">Estado</th><th className="pb-3 text-right font-normal">Total</th></tr></thead><tbody>{orders.map((order) => <tr key={order.id} className="border-b border-white/5 last:border-0"><td className="py-4 text-[#d9c99e]">{order.id}</td><td className="py-4">{order.customer}</td><td className="py-4"><Status value={order.status} /></td><td className="py-4 text-right">{formatARS(order.total)}</td></tr>)}</tbody></table></div></section><section className="border border-white/10 bg-[#111] p-6"><p className="text-[10px] uppercase tracking-[0.3em] text-[#c8b995]">Resumen</p><h2 className="mt-2 font-serif text-2xl">Rendimiento</h2><div className="mt-8 flex h-44 items-end gap-3">{[38, 54, 48, 70, 62, 84, 76].map((height, index) => <div key={index} className="flex flex-1 flex-col items-center gap-2"><div className={`w-full ${index === 5 ? 'bg-[#c8b995]' : 'bg-[#c8b995]/25'}`} style={{ height: `${height}%` }} /><span className="text-[10px] text-white/30">{['L', 'M', 'X', 'J', 'V', 'S', 'D'][index]}</span></div>)}</div><p className="mt-5 text-xs text-white/40">Las ventas subieron <span className="text-emerald-300">12,8%</span> esta semana.</p></section></div></div>
}

function Status({ value }: { value: string }) { return <span className={`inline-flex rounded-full px-2.5 py-1 text-[10px] ${statusClasses[value] ?? 'bg-white/10 text-white/60'}`}>{value}</span> }

function Products({ products, onAdd, onEdit }: { products: AdminProduct[]; onAdd: () => void; onEdit: (product: AdminProduct) => void }) { return <div className="flex flex-col gap-6"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="text-[10px] uppercase tracking-[0.3em] text-[#c8b995]">Catálogo</p><h2 className="mt-2 font-serif text-3xl">Tus productos</h2></div><button onClick={onAdd} className="inline-flex items-center justify-center gap-2 bg-[#c8b995] px-4 py-3 text-xs font-semibold uppercase tracking-[0.15em] text-black hover:bg-[#e0d0a7]"><PackagePlus className="size-4" />Agregar producto</button></div><DataTable><thead><tr><th>Producto</th><th>Categoría</th><th>Precio</th><th>Stock</th><th>Estado</th><th /></tr></thead><tbody>{products.map((product) => <tr key={product.id}><td className="font-medium">{product.name}</td><td className="text-white/45">{product.category}</td><td>{formatARS(product.price)}</td><td>{product.stock}</td><td><Status value={product.status} /></td><td className="text-right"><button onClick={() => onEdit(product)} className="text-xs text-white/40 hover:text-white">Editar</button></td></tr>)}</tbody></DataTable></div> }

function Orders({ orders }: { orders: AdminOrder[] }) { return <div className="flex flex-col gap-6"><div><p className="text-[10px] uppercase tracking-[0.3em] text-[#c8b995]">Operaciones</p><h2 className="mt-2 font-serif text-3xl">Todos los pedidos</h2></div><DataTable><thead><tr><th>Pedido</th><th>Cliente</th><th>Artículos</th><th>Total</th><th>Estado</th><th>Fecha</th></tr></thead><tbody>{orders.map((order) => <tr key={order.id}><td className="text-[#d9c99e]">{order.id}</td><td><p>{order.customer}</p><p className="text-xs text-white/35">{order.email}</p></td><td>{order.items}</td><td>{formatARS(order.total)}</td><td><Status value={order.status} /></td><td className="text-white/45">{order.date}</td></tr>)}</tbody></DataTable></div> }

function Customers({ customers }: { customers: AdminCustomer[] }) { return <div className="flex flex-col gap-6"><div><p className="text-[10px] uppercase tracking-[0.3em] text-[#c8b995]">Comunidad</p><h2 className="mt-2 font-serif text-3xl">Clientes registrados</h2></div><DataTable><thead><tr><th>Cliente</th><th>Pedidos</th><th>Total gastado</th><th>Alta</th><th /></tr></thead><tbody>{customers.map((customer) => <tr key={customer.id}><td><p>{customer.name}</p><p className="text-xs text-white/35">{customer.email}</p></td><td>{customer.orders}</td><td>{formatARS(customer.spent)}</td><td className="text-white/45">{customer.joined}</td><td className="text-right"><button className="text-xs text-white/40 hover:text-white">Ver perfil</button></td></tr>)}</tbody></DataTable></div> }

function DataTable({ children }: { children: ReactNode }) { return <div className="overflow-x-auto border border-white/10 bg-[#111]"><table className="w-full min-w-[700px] text-left text-sm [&_tbody_tr]:border-t [&_tbody_tr]:border-white/5 [&_td]:px-6 [&_td]:py-5 [&_th]:px-6 [&_th]:py-4 [&_th]:text-[10px] [&_th]:font-normal [&_th]:uppercase [&_th]:tracking-[0.15em] [&_th]:text-white/35">{children}</table></div> }

function ProductForm({ onClose, product }: { onClose: () => void; product?: AdminProduct }) {
  const [imageUrl, setImageUrl] = useState(product?.imageUrl ?? '')
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState('')

  async function handleImageChange(event: ChangeEvent<HTMLInputElement>) {
    const image = event.target.files?.[0]
    if (!image) return
    setUploadError('')
    setUploading(true)
    try {
      const body = new FormData()
      body.append('image', image)
      const response = await fetch('/api/upload-image', { method: 'POST', body })
      const result = await response.json()
      if (!response.ok) throw new Error(result.error || 'No pudimos subir la imagen.')
      setImageUrl(result.url)
    } catch (error) {
      setUploadError(error instanceof Error ? error.message : 'No pudimos subir la imagen.')
    } finally {
      setUploading(false)
      event.target.value = ''
    }
  }

  return <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/75 p-5"><div className="max-h-[90vh] w-full max-w-lg overflow-y-auto border border-white/10 bg-[#151515] p-6 shadow-2xl"><div className="flex items-start justify-between"><div><p className="text-[10px] uppercase tracking-[0.25em] text-[#c8b995]">{product ? 'Editar registro' : 'Nuevo registro'}</p><h2 className="mt-2 font-serif text-2xl">{product ? 'Editar producto' : 'Agregar producto'}</h2></div><button onClick={onClose} aria-label="Cerrar formulario"><X className="size-5 text-white/50" /></button></div><form className="mt-7 flex flex-col gap-5" onSubmit={(event) => { event.preventDefault(); onClose() }}><label className="flex flex-col gap-2 text-xs text-white/55">Nombre<input required defaultValue={product?.name} className="border border-white/10 bg-[#0b0b0b] px-3 py-3 text-sm text-white outline-none focus:border-[#c8b995]" placeholder="Ej. Remera Eclipse" /></label><div className="grid gap-5 sm:grid-cols-2"><label className="flex flex-col gap-2 text-xs text-white/55">Precio<input required type="number" defaultValue={product?.price} className="border border-white/10 bg-[#0b0b0b] px-3 py-3 text-sm text-white outline-none focus:border-[#c8b995]" placeholder="15000" /></label><label className="flex flex-col gap-2 text-xs text-white/55">Stock<input required type="number" defaultValue={product?.stock} className="border border-white/10 bg-[#0b0b0b] px-3 py-3 text-sm text-white outline-none focus:border-[#c8b995]" placeholder="10" /></label></div><div className="flex flex-col gap-3"><span className="text-xs text-white/55">Imagen del producto</span><label className="flex cursor-pointer items-center justify-center gap-2 border border-dashed border-white/20 bg-[#0b0b0b] px-4 py-6 text-xs uppercase tracking-[0.12em] text-white/60 hover:border-[#c8b995] hover:text-[#c8b995]">{uploading ? <><span className="size-4 animate-spin rounded-full border-2 border-[#c8b995] border-t-transparent" />Subiendo...</> : 'Subir imagen'}<input type="file" accept="image/jpeg,image/png,image/webp,image/gif" onChange={handleImageChange} disabled={uploading} className="sr-only" /></label>{imageUrl && <div className="flex items-center gap-3"><img src={imageUrl} alt="Vista previa del producto" className="size-16 object-cover" /><p className="truncate text-xs text-emerald-300">Imagen subida correctamente</p></div>}{uploadError && <p role="alert" className="text-xs text-red-300">{uploadError}</p>}<input type="hidden" name="imagenUrl" value={imageUrl} /></div><div className="flex justify-end gap-3 border-t border-white/10 pt-5"><button type="button" onClick={onClose} className="px-4 py-3 text-xs uppercase tracking-[0.15em] text-white/50 hover:text-white">Cancelar</button><button disabled={uploading} className="bg-[#c8b995] px-4 py-3 text-xs font-semibold uppercase tracking-[0.15em] text-black disabled:cursor-not-allowed disabled:opacity-50">Guardar producto</button></div></form></div></div>
}
