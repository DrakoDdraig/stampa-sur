'use client'

import { ChangeEvent, useEffect, useState } from 'react'
import { CONFIG_PERSONALIZACION as config } from '@/config/personalizacion'
import { ScrollReveal } from '@/components/motion-effects'

function ShirtPreview({ color, design }: { color: string; design: string }) {
  return <div className="relative mx-auto aspect-[0.85] w-full max-w-[360px] overflow-hidden rounded-sm bg-[#0d0d0d] p-5 shadow-[0_20px_70px_rgba(0,0,0,0.45)]"><svg viewBox="0 0 360 430" className="h-full w-full" role="img" aria-label="Vista previa de la remera"><path fill={color} d="M92 54 142 25h76l50 29 78 73-45 58-43-37v244H102V148l-43 37-45-58 78-73Z" /><path fill="none" stroke="rgba(255,255,255,.16)" strokeWidth="3" d="M142 25c8 31 20 45 38 45s30-14 38-45M102 148l22 18m134-18-22 18" /></svg>{design && <img src={design} alt="Tu diseño sobre la remera" className="absolute left-1/2 top-[45%] max-h-28 w-28 -translate-x-1/2 -translate-y-1/2 object-contain" />}</div>
}

export function ShirtCustomizer() {
  const [size, setSize] = useState<string>(config.tallesDisponibles[1])
  const [color, setColor] = useState(config.coloresDisponibles[0])
  const [design, setDesign] = useState('')
  const [notes, setNotes] = useState('')

  useEffect(() => () => { if (design) URL.revokeObjectURL(design) }, [design])

  function handleDesign(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0]
    if (!file) return
    if (design) URL.revokeObjectURL(design)
    setDesign(URL.createObjectURL(file))
  }

  function openWhatsApp(message: string) {
    window.open(`https://wa.me/${config.whatsappNumber}?text=${encodeURIComponent(message)}`, '_blank', 'noopener,noreferrer')
  }

  const message = `${config.mensajeWhatsapp}\n\nCliente: [completar]\nProducto: Remera personalizada\nTalle: ${size}\nColor: ${color.nombre}\nDiseño: El cliente adjunta la imagen por WhatsApp\nPrecio estimado: $${config.precioBase.toLocaleString('es-AR')}\nNotas: ${notes || '[sin notas]'}`
  const helpMessage = 'Hola Stampa Sur! Quiero una remera personalizada pero no tengo el diseño. ¿Me pueden ayudar a crearlo?'

  return <section id="personalizar" className="border-y border-white/10 bg-[#11100e] px-5 py-20 lg:px-10"><ScrollReveal className="mx-auto max-w-7xl"><div className="mb-12 max-w-3xl"><p className="mb-4 text-[10px] uppercase tracking-[0.4em] text-[#c8b995]">Diseñá la tuya</p><h2 className="font-serif text-5xl leading-none sm:text-7xl">Personalizá tu estampa</h2><p className="mt-6 text-sm leading-7 text-white/55">Elegí cómo querés empezar. El diseño y la coordinación final se resuelven por WhatsApp.</p></div><div className="grid gap-5 lg:grid-cols-2"><div className="border border-white/10 bg-[#0b0b0b] p-6 sm:p-8"><p className="text-[10px] uppercase tracking-[0.3em] text-[#c9a961]">Camino A</p><h3 className="mt-3 font-serif text-3xl">Ya tengo mi diseño</h3><div className="mt-8 flex flex-col gap-6"><fieldset><legend className="mb-3 text-[10px] uppercase tracking-[0.25em] text-white/55">Talle</legend><div className="flex flex-wrap gap-2">{config.tallesDisponibles.map(item => <button type="button" key={item} onClick={() => setSize(item)} aria-pressed={size === item} className={`size-11 border text-xs transition ${size === item ? 'border-[#c9a961] bg-[#c9a961] text-black' : 'border-white/15 text-white/65 hover:border-[#c9a961]'}`}>{item}</button>)}</div></fieldset><fieldset><legend className="mb-3 text-[10px] uppercase tracking-[0.25em] text-white/55">Color · {color.nombre}</legend><div className="flex flex-wrap gap-3">{config.coloresDisponibles.map(item => <button type="button" key={item.nombre} onClick={() => setColor(item)} aria-label={item.nombre} aria-pressed={color.nombre === item.nombre} className={`size-9 rounded-full border-2 ${color.nombre === item.nombre ? 'border-[#c9a961] ring-2 ring-[#c9a961]/30 ring-offset-2 ring-offset-[#0b0b0b]' : 'border-white/25'}`} style={{ backgroundColor: item.hex }} />)}</div></fieldset><div><p className="mb-3 text-[10px] uppercase tracking-[0.25em] text-white/55">Preview en vivo</p><ShirtPreview color={color.hex} design={design} /><p className="mt-3 text-center text-[10px] uppercase tracking-[0.2em] text-white/35">{size} · {color.nombre}</p></div><div><label htmlFor="design-upload" className="block cursor-pointer border border-dashed border-white/20 px-4 py-4 text-xs uppercase tracking-[0.15em] text-[#c9a961] transition hover:border-[#c9a961]">{design ? 'Cambiar diseño PNG' : 'Subir diseño PNG'}</label><input id="design-upload" type="file" accept="image/png" onChange={handleDesign} className="sr-only" /><p className="mt-3 text-xs leading-6 text-white/55">Subí tu diseño en PNG con fondo transparente. Si la imagen tiene fondo, se va a estampar tal cual.</p></div><label className="text-[10px] uppercase tracking-[0.25em] text-white/55">Notas opcionales<textarea value={notes} onChange={event => setNotes(event.target.value)} rows={3} placeholder="Contanos algún detalle" className="mt-3 w-full resize-none border border-white/15 bg-transparent px-4 py-3 text-sm normal-case tracking-normal text-white outline-none placeholder:text-white/30 focus:border-[#c9a961]" /></label><button type="button" onClick={() => openWhatsApp(message)} className="w-full bg-[#c9a961] px-6 py-4 text-[10px] font-semibold uppercase tracking-[0.25em] text-black transition hover:bg-[#eadcb8]">Finalizar pedido</button></div></div><div className="border border-white/10 bg-[#0b0b0b] p-6 sm:p-8"><p className="text-[10px] uppercase tracking-[0.3em] text-[#c9a961]">Camino B</p><h3 className="mt-3 font-serif text-3xl">Quiero que me diseñen</h3><p className="mt-5 text-sm leading-7 text-white/55">No tenés diseño todavía? Nuestro equipo puede ayudarte a crear una idea única.</p><button type="button" onClick={() => openWhatsApp(helpMessage)} className="mt-8 inline-flex bg-[#c9a961] px-6 py-4 text-[10px] font-semibold uppercase tracking-[0.25em] text-black transition hover:bg-[#eadcb8]">No tengo diseño, ayúdenme</button></div></div></ScrollReveal></section>
}
